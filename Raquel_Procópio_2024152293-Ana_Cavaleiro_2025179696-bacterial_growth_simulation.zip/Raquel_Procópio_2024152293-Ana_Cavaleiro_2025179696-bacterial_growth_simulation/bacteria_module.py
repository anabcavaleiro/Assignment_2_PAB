class Bacterium():
    """
    Represents each species of bacterium
    Stores information
    Has methods to: control the internal state of the bacteria and return the current size
    """
    def __init__(self, name, symbol, growth_rate, division_threshold):
        self.name = name
        self.symbol = symbol
        self.growth_rate = growth_rate
        self.division_threshold = division_threshold
        self.size = 0 

    def updt_growth(self):
        """
        Updates the bacterium's internal state
        """
        self.size += self.growth_rate

    def current_size(self):
        """
        Returns the current size of the bacteria
        """
        return self.size
    
    def division_attempt(self):
        if self.size >= self.division_threshold:
            return True 