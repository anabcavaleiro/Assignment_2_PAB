class Grid ():
    """
    Provides methods to: place a bacterium, check if cell is empty, obtain neighboring positions of a cell, prints the grid 
    """
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.grid = []
        for y in range(height): #para cada coisa em height (Y)
            row = []
            for x in range(width): #para cada coisa em width (X)
                row.append(0)
            self.grid.append(row)

    def is_cell_empty(self, y, x):
        """
        Returns true if chosen cell is empty
        If not returns false
        """
        if 0 <= y < self.height and 0 <= x < self.width: #container 
            return self.grid[y][x] == 0
        
        else:
            return False

    def place_bacteria(self, y, x, placed_bacteria):
        """
        Places bacterium at a position
        """
        if self.is_cell_empty(y, x):
            self.grid[y][x] = placed_bacteria #se nao tiver ocupada mete
            return True
        
        else: #se estiver ocupada nao coloca
            return False
    
    #def com neighbors random com as cordenadas henrique e professor ideia
    def is_neighbor(self, y, x):
        """
        Returns positions of neighboring cells
        """
        neighbors = [(y+1, x), (y-1, x), (y, x+1), (y, x-1)]
        return neighbors

    def print_grid(self):
        """
        Prints the grid
        empty cell use 0, occupied cell use bacteria symbol
        """
        for row in self.grid: #para cada linha da matriz da grid
            for cell in row:
                if cell == 0:
                    symbol = "0"
                
                else: #mete o simbolo, acontece depois do place_bacteria
                    symbol = cell.symbol
                print(symbol, end=" ")

            print() #print de cada row
