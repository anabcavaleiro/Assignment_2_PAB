import argparse
import json
import bacteria_module
import grid_module
import random
import time
import csv

parser = argparse.ArgumentParser()
parser.add_argument("width", type=int, help="Width of grid")
parser.add_argument("height", type=int, help="Height of grid")
parser.add_argument("simul_steps", type=int, help="Simulation steps")
parser.add_argument("print_frq", type=int, help="Frequency of the steps as which the grid is printed")
parser.add_argument("json_file", help="Path of the .json file with the species configurations")
parser.add_argument("csv_output", help="Path of the .csv output file")
args = parser.parse_args()
    
with open(args.json_file, "r") as json_file:
    properties = json.load(json_file)

def population(properties):
    bacteria_population = []
    for specie in properties["species"]:
        for nr in range(specie["initial_count"]):
            name = specie["name"]
            symbol = specie["symbol"]
            growth_rate = specie["growth_rate"]
            division_threshold = specie["division_threshold"]
            new_bacterium = bacteria_module.Bacterium(name, symbol, growth_rate, division_threshold)
            bacteria_population.append(new_bacterium)
    return bacteria_population 

Bac_Population = population(properties)
Bac_Grid = grid_module.Grid(args.width, args.height)

class Simulation():
    '''
    Methods to:
    Initialize grid and starting population
    Advances the simulation by one time step and runs the simulation for a given number of steps
    Controls how often the grid is printed
    Logs population statistics to a CSV file
    '''
    def __init__(self, grid, bacteria_population, csv_file, properties):
        self.grid = grid
        self.bacteria_population = bacteria_population
        self.csv_file = csv_file
        self.name_list = [] #cria uma lista e dps dá append aos nomes species
        self.properties = properties

        for specie in properties["species"]:
            specie_name = specie["name"]
            self.name_list.append(specie_name)
        
    def grid_initialization(self):
        """
        Initializes the grid and the starting population
        Places each bacterium in random position
        """
        for bacterium in self.bacteria_population:
            while True: 
                x = random.randrange(self.grid.width) #x aleatorio
                y = random.randrange(self.grid.height) #y aleatorio

                if self.grid.place_bacteria(y, x, bacterium): #agora ve se a celula ta com 0, e depois mete la no x e y cada bacteria
                    break
                    
    def will_divide(self, y, x, bacterium):
        """
        Check if a random neighbor is empty, and if it is, divide to that neighbor. 
        If not, try another neighbor. Finally, if none are empty, do not divide.
        """
        neighbors = self.grid.is_neighbor(y, x)

        #ideia do professor e henrique na aula
        while neighbors: #enquanto ainda existem vizinhos na lista, eles vao sendo removidos se nao forem aptos (igual a 0, vazios)
            chosen_neighbor = random.choice(neighbors)
            nb_y = chosen_neighbor[0] #y
            nb_x = chosen_neighbor[1] #x

            if self.grid.is_cell_empty(nb_y, nb_x): #ve se ta vazia a cell
                new_bact = bacteria_module.Bacterium(bacterium.name, bacterium.symbol, bacterium.growth_rate, bacterium.division_threshold)
                
                self.grid.place_bacteria(nb_y, nb_x, new_bact)

                bacterium.size = 0 #reseta, mitose
                return True #dividiu
            
            else:
                neighbors.remove(chosen_neighbor) #se n tiver vazia remove dos vizinhos

        return False #se forem removidos todos os vizinhos nao pode dividir obvio
    
    def step_by_step(self, simul_steps, print_frq):
            
        with open(self.csv_file, mode="w", newline="") as csv_file:
            writer = csv.writer(csv_file)
            header = ["Step"] + self.name_list
            writer.writerow(header)

            accumulated_bac_count = {} #para fazer o contador onde se add as quantidades de bacterias 
            for specie in self.properties["species"]:
                    accumulated_bac_count[specie["name"]] = specie["initial_count"] #no step 1 as bacterias iniciais sao iguais ao inital count da especie

        for step in range(1, simul_steps + 1):

            for y in range(self.grid.height):
                for x in range(self.grid.width):
                    bact = self.grid.grid[y][x]

                    if bact != 0:
                        bact.updt_growth()
                        
                        if bact.division_attempt():
                            
                            if self.will_divide(y, x, bact):
                                accumulated_bac_count[bact.name] += 1

            with open(self.csv_file, mode="a", newline="") as csv_file:
                writer = csv.writer(csv_file)
                row = [step]
                for name in self.name_list:
                    row.append(accumulated_bac_count[name]) #adiciona o valor do contador
                writer.writerow(row)

            if step % print_frq == 0:
                print(f"\033[H\033[JStep {step}") #https://www.reddit.com/r/learnpython/comments/yyx459/2_beginner_questions/
                self.grid.print_grid()
                time.sleep(2)

simulacao_inicial = Simulation(Bac_Grid, Bac_Population, args.csv_output, properties)
simulacao_inicial.grid_initialization()
Bac_Grid.print_grid()
simulacao_inicial.step_by_step(args.simul_steps, args.print_frq)